---
title: "Are Airpods Supposed To Light Up Blue? [Solved]"
ShowToc: true 
date: "2022-08-20"
author: "Mark Finley" 
---

Hola, iam Mark Finley, I bid you good day, sir/ma’am.
## Are Airpods Supposed To Light Up Blue? [Solved]
If your new AirPods flash or glow blue, it means your money just went down the drain. You have been scammed into purchasing a fake AirPods pair. Real AirPods do not emit blue light.

## The cloned airpods headphones are lit blue and cannot be connected to the phone? （1536u or1536p）
{{< youtube WC7xy-JosGw >}}
>For the 

## Do real AirPods light up blue and red?
{{< youtube V-cz88NmWVs >}}
>Find 

## i9s TWS versus Apple Airpods - physical features
{{< youtube QgYjRfdXKHU >}}
>In this video you'll get to see the physical differences between the real apple 

