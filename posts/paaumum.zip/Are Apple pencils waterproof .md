---
title: "Are Apple Pencils Waterproof? [Solved]"
ShowToc: true 
date: "2022-04-17"
author: "Ruben Robinson" 
---

Namaste, iam Ruben Robinson, So long!
## Are Apple Pencils Waterproof? [Solved]
 The Apple Pencil 2 is neither waterproof nor officially water resistant. Apple doesn't mention an IP rating for it. So while it may survive water splashes, we advise you to keep it away from a direct liquid stream.Aug 7, 2022

## Why The Apple Pencil Is So Expensive
{{< youtube wlRfHlMhMRU >}}
>Many iPad customers like the idea of a 

## 10 Reasons Why The Apple Pencil is WORTH IT! Unlock Hidden Features
{{< youtube ssYHGenoN3s >}}
>Why the 

## Apple Pencil VS Amazon Pencil - which is better?
{{< youtube hV0DKVyrWVA >}}
>Sorry for the weird editing with camera and audio. IDK what weird decisions I made while making this. 

