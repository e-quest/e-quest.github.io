---
title: "Are Christmas Parties Tax Deductible? [Solved]"
ShowToc: true 
date: "2021-10-19"
author: "Jean Madruga" 
---

Hi, iam Jean Madruga, Have a good day!
## Are Christmas Parties Tax Deductible? [Solved]
Christmas parties cannot be claimed as an income tax deduction. Your gift to employees, associates and clients should fall below $300 to be considered a minor benefits exemption.Dec 8, 2020

## £150 CHRISTMAS PARTIES ARE TAX DEDUCTIBLE!
{{< youtube DfIPm6ZB5Is >}}
>Did you know that there is a 

## Is my Christmas party tax deductible?
{{< youtube wcET_4jDmuY >}}
>Sorry to mention the C word already, but I know I'm not the only business owner already thinking ahead to booking a 

## Christmas Parties and Tax  - How wine is tax deductible
{{< youtube ZTQ3Dr4cM-E >}}
>If you need to speak to an Accountant about a Australian 

