---
title: "Are Etfs Only Taxed When Sold? [Solved]"
ShowToc: true 
date: "2022-03-07"
author: "Burton Wheatley" 
---

Hello, iam Burton Wheatley, I bid you good day, sir/ma’am.
## Are Etfs Only Taxed When Sold? [Solved]
Just as with individual securities, when you sell shares of a mutual fund or ETF (exchange-traded fund) for a profit, you'll owe taxes on that "realized gain." But you may also owe taxes if the fund realizes a gain by selling a security for more than the original purchase price—even if you haven't sold any shares.

## ETF and MUTUAL FUND TAXES - How are you taxed on ETFs?
{{< youtube 8laJYxXbOKY >}}
>How 

## Are ETFs tax-efficient?
{{< youtube IVgwr3F54RU >}}
>ETFs

## Just How Tax Efficient are ETFs?
{{< youtube lH_yU6TMsjw >}}
>Strategy and structure make 

