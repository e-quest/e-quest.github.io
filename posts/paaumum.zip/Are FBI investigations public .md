---
title: "Are Fbi Investigations Public? [Solved]"
ShowToc: true 
date: "2021-11-12"
author: "Lois Milton" 
---

Sup, iam Lois Milton, Have a nice day.
## Are Fbi Investigations Public? [Solved]
 Can I obtain detailed information about a current FBI investigation that I see in the news? No. Such information is protected from public disclosure, in accordance with current law and Department of Justice and FBI policy.

## What is the FBI doing in its investigations?
{{< youtube HjF-mvcm_5Q >}}
>Co-Counselor to Steve Friend, Dan Meyer, discusses on 'Fox & Friends Weekend' the treatment of 

## Bombshell evidence revealed in FBI scandal
{{< youtube fVTjSnDBZiA >}}
>Former Trump campaign adviser Carter Page discusses 

## FBI Public Corruption Task Force takes over investigation into CPD Vice Unit
{{< youtube vn7Cgjs3WTc >}}
>FBI Public

