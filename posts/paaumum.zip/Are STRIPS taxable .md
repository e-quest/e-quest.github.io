---
title: "Are Strips Taxable? [Solved]"
ShowToc: true 
date: "2022-05-06"
author: "Brandon Lindsey" 
---

Greetings, iam Brandon Lindsey, Have a nice day.
## Are Strips Taxable? [Solved]
Most STRIPS are tax-free at both federal and state levels, thus making them a viable substitute for both Certificates of Accrual on Treasury Security (CATS) and Treasury Investment Growth Receipts (TIGRs) which were the most bought zero-coupon based debt instruments.

## How I built a US $1 Million Treasury Ladder in my Taxable account?
{{< youtube 0c4zRLv-grQ >}}
>Why is it the best time to create Treasury Ladder in your fixed income portfolio? Learn how I've created a US $1 Million fixed ...

## State Taxation and Remote Work
{{< youtube v5WbbyNa_z4 >}}
>The pandemic has changed how we live and work, and for many, some of those changes may be permanent. But what are the tax ...

## SIE Exam Tomorrow?  This Afternoon?  Pass?  Fail?  This 60 Minutes May Be The Difference!
{{< youtube _hQRLmVspNE >}}
>https://youtu.be/KegLDJJKMbc another popular day before SIE Exam video Time stamps: 00:00 Introduction 1:00 CAPITAL ...

