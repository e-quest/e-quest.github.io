---
title: "Are Series I Bonds A Good Idea? [Solved]"
ShowToc: true 
date: "2022-06-13"
author: "John Selva" 
---

Namaste, iam John Selva, Hope you're doing well!
## Are Series I Bonds A Good Idea? [Solved]
Key Points. Series I bonds are paying an unprecedented 9.62% annual interest rate. I bonds can be a good option for cash you don't need right away, but they aren't a substitute for emergency savings or investments. The 9.62% interest rate is likely to be short-lived as the Fed intervenes to curb inflation.

## I Bonds Explained! (Is 7.12% Guaranteed for Real?)
{{< youtube sIMJo6UZ0hc >}}
>I 

## Why You Should ONLY Buy I Bonds in April or October (Series I Savings Bonds)
{{< youtube jkpTlGmQ9go >}}
>With inflation at 30-year highs, everyone's getting amped up about 

## I-Bonds - Pros & Cons
{{< youtube 6RnUa7W7mYA >}}
>Are Inflation Adjusted 

