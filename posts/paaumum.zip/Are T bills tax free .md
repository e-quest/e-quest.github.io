---
title: "Are T Bills Tax Free? [Solved]"
ShowToc: true 
date: "2022-05-11"
author: "Lillie Smith" 
---

Sup, iam Lillie Smith, Hope you're having a great week!
## Are T Bills Tax Free? [Solved]
Key Takeaways. Interest from Treasury bills (T-bills) is subject to federal income taxes but not state or local taxes. The interest income received in a year is recorded on Form 1099-INT. Investors can opt to have up to 50% of their Treasury bills' interest earnings automatically withheld.

## Treasury Bills (T-Bills) 11170
{{< youtube GdDWDXkwxs0 >}}
>Treasury Bills

## Are I Bonds or Treasury Bills a Good Investment Right Now?
{{< youtube jVjkdcAE12I >}}
>Let's make sure you're on the path to financial success - then help you stay there! The Money Guy Show takes the edge off of ...

## Treasury Bills vs. Bank CDs | Which is Better Right Now?
{{< youtube mDvARC8caEQ >}}
>Treasury Bills

