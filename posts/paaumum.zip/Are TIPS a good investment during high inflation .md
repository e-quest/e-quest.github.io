---
title: "Are Tips A Good Investment During High Inflation? [Solved]"
ShowToc: true 
date: "2022-02-03"
author: "Deborah Fifield" 
---

Howdy, iam Deborah Fifield, Don’t overdo it!
## Are Tips A Good Investment During High Inflation? [Solved]
“TIPS are by far the best inflation hedge for the average investor,” she tells Select. TIPS bonds pay interest twice a year at a fixed rate, and they are issued in 5-, 10- and 30-year maturities. At maturity, investors are paid the adjusted principal or original principal, whichever is greater.

## Warren Buffett Explains How To Invest During High Inflation
{{< youtube 2NdCZKcU-68 >}}
>Inflation

## Peter Lynch: How to Invest During High Inflation
{{< youtube Zpthvpy3UKg >}}
>Peter Lynch (author of One Up On Wall Street) gave an iconic speech back 

## The Best Way To Invest During High Inflation
{{< youtube 7t6QId3yOnI >}}
>While

