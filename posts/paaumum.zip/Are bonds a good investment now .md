---
title: "Are Bonds A Good Investment Now? [Solved]"
ShowToc: true 
date: "2022-02-17"
author: "Stanley Lindsey" 
---

Greetings, iam Stanley Lindsey, Hope you're having a great day!
## Are Bonds A Good Investment Now? [Solved]
Now that inflation has surged, I Bonds have become not just competitive but quite attractive. The current interest rates for securities issued through October 2022 are 9.62%, which is many times higher than the average rate paid on a bank savings account.Sep 14, 2022

## Are Bonds Bad Investments Now?
{{< youtube 5VGHHJVIMeg >}}
>I want to give a huge thank you to George Kao whose generous support on Patreon is helping to keep this channel in the black!

## Why I’m Buying Bonds
{{< youtube bLsEOsXd-K4 >}}
>2022 has seen one of the worst bond crash ever, and it's interesting that when this happens to equity people say you should buy it ...

## Is it Time to Invest in Bonds?
{{< youtube WKz5V_6LgJo >}}
>Want to know a neat trick on how you can lower the volatility of your 

