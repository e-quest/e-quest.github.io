---
title: "Are Bonds A Good Investment Now 2022? [Solved]"
ShowToc: true 
date: "2022-05-29"
author: "Taylor Mealy" 
---

Namaste, iam Taylor Mealy, G’day, mate.
## Are Bonds A Good Investment Now 2022? [Solved]
However, recent survey data does suggest that inflation is expected to decline over the coming years and if that holds it could be good news for bonds. Yes, bonds have had a tough run in 2022, but with currently higher yields, if you're optimistic on inflation, bonds may make sense in your portfolio.Sep 20, 2022

## 2022: Year of the bond? Two ETF experts on what to watch
{{< youtube G7l7DI8AJXE >}}
>Turn to CNBC TV for the latest stock market news and analysis. From market futures to live price updates CNBC is the leader in ...

## Why I’m Buying Bonds
{{< youtube bLsEOsXd-K4 >}}
>2022

## Is it Time to Invest in Bonds?
{{< youtube WKz5V_6LgJo >}}
>Want to know a neat trick on how you can lower the volatility of your 

