---
title: "Are Bonds Good During Inflation? [Solved]"
ShowToc: true 
date: "2021-10-31"
author: "Robert Conger" 
---

Greetings, iam Robert Conger, Have an A+ day.
## Are Bonds Good During Inflation? [Solved]
Inflation erodes the purchasing power of a bond's future cash flows. Typically, bonds are fixed-rate investments. If inflation is increasing (or rising prices), the return on a bond is reduced in real terms, meaning adjusted for inflation.

## The Significance Of Inflation On Bonds
{{< youtube 0DfANiV6ncY >}}
>------------------------ The significance of 

## Warren Buffett Explains How To Invest During High Inflation
{{< youtube 2NdCZKcU-68 >}}
>Inflation

## The Impact of Inflation on Stocks, Bonds, and Cash
{{< youtube 48uIEakjRDY >}}
>The 

