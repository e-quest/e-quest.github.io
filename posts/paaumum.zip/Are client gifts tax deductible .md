---
title: "Are Client Gifts Tax Deductible? [Solved]"
ShowToc: true 
date: "2022-01-02"
author: "Michelle Kirchoff" 
---

Sup, iam Michelle Kirchoff, Enjoy your time-off from me!
## Are Client Gifts Tax Deductible? [Solved]
Gifts for clients Whether it's a gift to say thank you for being a valuable client, or for a holiday, the good news is that client gifts are tax-deductible, but they have limits. Businesses can deduct $25 in gifts per person per year. These limits also apply to freelancers or contractors with whom you do business.

## Tax Tip Tuesday: Are Client Gifts Tax Deductible?
{{< youtube jKIZO3C3nFQ >}}
>Client gifts

## Can Business Gifts Be Tax Deductible?
{{< youtube MX8WxeUiEx4 >}}
>Business 

## TAX TIP: THE TRUTH ABOUT WRITING OFF CLIENT GIFTS
{{< youtube Hb3lcrVC3Fc >}}
>In this video I explain what percentage of 

