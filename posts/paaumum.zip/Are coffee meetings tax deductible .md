---
title: "Are Coffee Meetings Tax Deductible? [Solved]"
ShowToc: true 
date: "2021-10-22"
author: "Walter Davis" 
---

Sup, iam Walter Davis, I hope all goes well today.
## Are Coffee Meetings Tax Deductible? [Solved]
Generally there is NO tax deduction for the provision of entertainment! Call it marketing, call it a business meeting or whatever but really if it smells and feels like entertainment of a client then it is unlikely to be a business deduction.Aug 2, 2019

## Is meeting clients for coffee tax deductible?
{{< youtube D-LIFkNWM1M >}}
>Meeting

## Is America's Favorite Drink Tax Deductible? Part 3
{{< youtube 7ceNWSUNZUI >}}
>Coffee

## Writing Off Your Coffee Shop Expenses
{{< youtube 7bDvj02bB9s >}}
>In this video I explain whether or not you can 

