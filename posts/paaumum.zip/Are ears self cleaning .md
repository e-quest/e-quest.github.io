---
title: "Are Ears Self Cleaning? [Solved]"
ShowToc: true 
date: "2022-02-18"
author: "Peggy Gantner" 
---

Hi, iam Peggy Gantner, Don’t overdo it!
## Are Ears Self Cleaning? [Solved]
 The ear is self-cleaning. No routine maintenance is required. If you're inserting swabs into your ears to remove earwax or prevent its buildup, think again. Earwax is produced within the ear canal and naturally migrates from deeper inside to outside.

## Should you Clean your Ears?
{{< youtube OuqATmleqTQ >}}
>In this House Expertise video, Dr. House shares his knowledge on whether you should 

## Forget Q-Tips — Here’s How You Should Be Cleaning Your Ears
{{< youtube ld_8zROYDzw >}}
>NYU Otologist Erich Voigt explains the proper way to 

## We got our ears professionally cleaned - and the results shocked us
{{< youtube v2te2rUxeGs >}}
>We went to the Clear 

