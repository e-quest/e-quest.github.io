---
title: "Are Employee Salaries An Expense? [Solved]"
ShowToc: true 
date: "2021-12-15"
author: "Corey Griffies" 
---

Namaste, iam Corey Griffies, I bid you good day, sir/ma’am.
## Are Employee Salaries An Expense? [Solved]
salaries expense. Salaries payable and salaries expense are similar concepts, but they have distinct roles in accounting. Salaries expense is how much an employee earned in salary. Salaries payable refers only to the amount of salary pay that employers have not yet distributed to employees.May 3, 2021

## Salaries and Wages Expense and Salaries and Wages Payable What’s the difference
{{< youtube qcIGQz9lw_Q >}}
>What Accounting subjects are covered in this tutorial service? Basic Accounting or Fundamentals of Accounting Partnership and ...

## Salaries and Wages Payable (Introductory)
{{< youtube MsczmIYJV24 >}}
>This video provides an introductory look at the accounting for accrued 

## What is the Adjusting Entry for Accrued Salaries/Wages Owed at the End of the Accounting Period?
{{< youtube Qz2-D1IT_o0 >}}
>Adjusting for Accrued 

