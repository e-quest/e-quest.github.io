---
title: "Are Family Members Excluded From Erc? [Solved]"
ShowToc: true 
date: "2022-09-25"
author: "Joseph Bathe" 
---

Howdy, iam Joseph Bathe, I hope your day goes well.
## Are Family Members Excluded From Erc? [Solved]
The wages to an individual who is a family member don't qualify for the ERC, but there is no limitation under this section on wages paid to the owners (working husband and spouse). Section 51(i)(1)(A) continues by addressing circumstances when the taxpayer is a corporation or other type of business entity.

## Why Family Employee Wages Don't Count | Understanding the ERC Greater Than 50% Ownership Rule
{{< youtube vQPKYGopoYI >}}
>The greater than 50% rule for Employee Retention Credit Disqualified Wages is a little difficult to understand. That's why Larry ...

## This is Your Biggest ERC Mistake! | Learn How Related Parties Disqualifies Family Employee Wages
{{< youtube D_Oh1fcYVsk >}}
>The number 1 mistake being made right now with the Employee Retention Credit and Qualified Wages is counting employee ...

## Employee Retention Tax Credit Update [$26,000 Per Employee] Available Until at Least 7/31/23
{{< youtube XQ2xVQxbL6o >}}
>ERTC Overview with LIVE Q&A on Employee Retention Tax Credit. What is the IRS 

