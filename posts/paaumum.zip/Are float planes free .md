---
title: "Are Float Planes Free? [Solved]"
ShowToc: true 
date: "2022-03-16"
author: "Mary Ross" 
---

Namaste, iam Mary Ross, So long!
## Are Float Planes Free? [Solved]
Well-known creator who's now using Floatplane LinusTechTips has a subscriber count of almost 20,000 followers. He offers supporters a starter subscription for $5.00/month or $50.00/year, or a premium subscription for $10.00/month or $100.00/year.

## Float Plane Operation
{{< youtube gcKT8ssJ-m0 >}}
>Uploaded by Canadian Flight Centre (http://www.cfc.aero) with permission of SmartPilot.ca (http://www.smartpilot.ca)

## Seaplanes: History and Future of these Amphibious Aircrafts | Free Documentary
{{< youtube maAdj5HvS5A >}}
>Seaplanes

## Blippi Flies a Seaplane | Airplanes for Kids and Fun Songs for Toddlers
{{< youtube ly0a8gwqeBs >}}
>Blippi flies in a 

