---
title: "Are Floatplanes Paid? [Solved]"
ShowToc: true 
date: "2021-12-01"
author: "Raul Purnell" 
---

Hola, iam Raul Purnell, I hope today is better than yesterday.
## Are Floatplanes Paid? [Solved]
Unlike YouTube which streams most of it's video for free and has to recover that cost via ads, every person streaming on Floatplane has paid money to stream that content.

## Seaplane & Floatplanes: What you need to know about flying floatplanes! Pay special attention to...
{{< youtube X7HuWX42qX8 >}}
>Seaplane & Floatplanes: What you need to know about flying 

## The Apple vs Floatplane saga continues...
{{< youtube a2G7ebccCtw >}}
>Get Tim Apple on the phone! Watch the full WAN Show: https://www.youtube.com/watch?v=sb5GlR3pjt8 ▻GET MERCH: ...

## Our Response to YouTube's Shenanigans - Floatplane is Finally Here!
{{< youtube oOOOfZWXPu4 >}}
>Creators Application: https://lmg.gg/Bxx6k Users Sign-Up: https://lmg.gg/YuvCX Get a limited time LTT x 

