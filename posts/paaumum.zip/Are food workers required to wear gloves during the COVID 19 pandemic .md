---
title: "Are Food Workers Required To Wear Gloves During The Covid-19 Pandemic? [Solved]"
ShowToc: true 
date: "2021-10-06"
author: "Harry Jones" 
---

Hola, iam Harry Jones, I bid you good day, sir/ma’am.
## Are Food Workers Required To Wear Gloves During The Covid-19 Pandemic? [Solved]
See full answerThe COVID-19 virus can contaminate disposable gloves in the same way it can get onto workers hands and contact surfaces. Removal of disposable gloves can lead to contamination of hands. Wearing disposable gloves can give you a false sense of security and may result in staff not washing hands as frequently as required. Handwashing is a greater protective barrier to infection than wearing of disposable gloves. Food businesses need to ensure adequate sanitary facilities are provided and ensure food workers thoroughly and frequently wash their hands. Soap and water is adequate for hand washing.

## For some fast-food workers, wearing gloves is optional
{{< youtube sBzSKZ_UEck >}}
>Erik Avanier visits several Jacksonville restaurants to see whether 

## Should you be wearing gloves out in public during the COVID-19 pandemic?
{{< youtube 7rS8JJeCn1A >}}
>ST. LOUIS — The CDC is recommending that everyone 

## #COVID19 Quick Tips: Delivery Safety
{{< youtube 79Zlr7Ih4_0 >}}
>Find more tips to keep 

