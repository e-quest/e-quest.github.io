---
title: "Are Gel Pens Allowed In Board Exams? [Solved]"
ShowToc: true 
date: "2022-06-09"
author: "Elaine Eads" 
---

Hi, iam Elaine Eads, Asalam walekum.
## Are Gel Pens Allowed In Board Exams? [Solved]
Yes, Blue or royal blue ink gel pens can be used.

## GEL PEN IS ALLOWED OR NOT ?|Pradeep Giri Update
{{< youtube ytDvE7lVLgY >}}
>GEL PEN

## Best Pen for Board Exams | Gel Pen vs Ball pen for exam #class10term2 #kelvin9and10
{{< youtube GpXcgIxPbXc >}}
>Comparing two nib 

## BEST PENS TO USE FOR BOARD EXAMS (for good handwriting and speed)! | CBSE CLASS 10!!
{{< youtube -Yef13HWTwM >}}
>ALL THE BEST FOR YOUR 

