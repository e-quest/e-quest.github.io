---
title: "Are Gifts To Staff Deductible? [Solved]"
ShowToc: true 
date: "2022-07-15"
author: "Samuel Ericsson" 
---

Hola, iam Samuel Ericsson, Have a happy day.
## Are Gifts To Staff Deductible? [Solved]
Gifts below $300 are a tax deductible expense providing they are classified as a 'non-entertainment' gift. The same rule applies for other special occasions such as birthdays. As long as these gifts are 'infrequent', you can claim a tax deduction for amounts of less than $300 for employees and there is no FBT.Dec 9, 2020

## Can Business Gifts Be Tax Deductible?
{{< youtube MX8WxeUiEx4 >}}
>Business 

## Are gifts for employees tax deductible?
{{< youtube xaKa5hu2iU8 >}}
>Generosity doesn't mean you can't make the tax savings you're entitled to. So here's all you need to know about the rules for ...

## Tax deductions on employee gifts & end of year functions
{{< youtube hbiyH5ZpvpY >}}
>As an employer, you may be thinking of 

