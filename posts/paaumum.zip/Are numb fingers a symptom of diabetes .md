---
title: "Are Numb Fingers A Symptom Of Diabetes? [Solved]"
ShowToc: true 
date: "2022-09-10"
author: "Madeline Jones" 
---

Hello, iam Madeline Jones, Peace out!
## Are Numb Fingers A Symptom Of Diabetes? [Solved]
High blood sugar (glucose) can injure nerves throughout the body. Diabetic neuropathy most often damages nerves in the legs and feet. Depending on the affected nerves, diabetic neuropathy symptoms include pain and numbness in the legs, feet and hands.

## Tingling and Numbness in Fingers
{{< youtube eiC9xMAdNXU >}}
>Dr. Leslie Sisco-Wise and Dr. Ross Dunbar discuss if larger smartphones can cause hand injuries from overuse. Dr. Dunbar says ...

## Managing diabetic neuropathy
{{< youtube yr8F0QjjXqc >}}
>Managing the complications of 

## Tingling and Numb Fingers | Ask the Doctor
{{< youtube E04w0GGh-Zc >}}
>What do 

