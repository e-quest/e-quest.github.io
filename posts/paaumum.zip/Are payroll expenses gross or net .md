---
title: "Are Payroll Expenses Gross Or Net? [Solved]"
ShowToc: true 
date: "2022-03-02"
author: "Helene Humphrey" 
---

Sup, iam Helene Humphrey, Good luck today!
## Are Payroll Expenses Gross Or Net? [Solved]
A company's net payroll for a period is its gross payroll minus deductions for Social Security, income tax and any other required withholding such as insurance premiums and 401k contributions. A company's gross payroll for a period is always higher than its net payroll.

## QuickBooks Online -  Why is gross pay on P&L instead of net pay?
{{< youtube INRI1WOZ1-U >}}
>This video explains why your 

## Net vs. Gross (Income, Pay/Salary, etc.) in One Minute: Definition/Difference, Explanation, Examples
{{< youtube 1IXAt33nz0A >}}
>Way too many people think they understand the difference between 

## Gross Pay Vs Net Pay: What's The Difference?  | Salary Negotiation Tips
{{< youtube _UepVi5bfhM >}}
>Gross Pay

