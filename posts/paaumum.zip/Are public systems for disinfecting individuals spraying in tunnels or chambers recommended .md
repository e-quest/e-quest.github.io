---
title: "Are Public Systems For Disinfecting Individuals (Spraying In Tunnels Or Chambers) Recommended? [Solved]"
ShowToc: true 
date: "2022-05-26"
author: "Louise Dempster" 
---

Hi, iam Louise Dempster, Promise me you’ll have a good time.
## Are Public Systems For Disinfecting Individuals (Spraying In Tunnels Or Chambers) Recommended? [Solved]
Spraying of individuals with disinfectants (such as in a tunnel, cabinet, or chamber) is not recommended under any circumstances. This practice could be physically and psychologically harmful and would not reduce an infected person's ability to spread the virus through droplets or contact. Even if someone who is infected with COVID-19 goes through a disinfection tunnel or chamber, as soon as they start speaking, coughing or sneezing they can still spread the virus.

## Design & Fabrication "COVID-19 Disinfectant Chamber Spray" within 10 Hours .. ??
{{< youtube ZO_Hahw_wfQ >}}
>Alat penyemprot disinfektan COVID-19 Bahan : - Besi Hollow 30x30x1.5 mm - Besi Grating 1x1 meter - Akrilik - Pompa air DC 120 ...

## Disinfectant Chamber: Aman atau Gak Sih?
{{< youtube vRvY8WdV3-0 >}}
>Pada Sabtu, 28 Maret 2020, Sekolah Farmasi ITB memberikan tanggapan, terkait maraknya penggunaan 

## Disinfect with 'drone spray and chambers'? Expert says "not recommended"
{{< youtube yaEUJ70d9po >}}
>Drone dispersed clouds of 

