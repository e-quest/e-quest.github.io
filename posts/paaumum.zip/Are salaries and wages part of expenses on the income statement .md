---
title: "Are Salaries And Wages Part Of Expenses On The Income Statement? [Solved]"
ShowToc: true 
date: "2022-01-22"
author: "Tony Throop" 
---

Hi, iam Tony Throop, Have a happy day.
## Are Salaries And Wages Part Of Expenses On The Income Statement? [Solved]
The salaries and wages expense is presented on the income statement, usually within the operating expenditure section.

## Salaries and wages
{{< youtube i1UyTDMnD6c >}}
>Good day learners in today's lesson I just want to do a quick recap on 

## Salaries Expense 145
{{< youtube EiliyxXWaJw >}}
>Spanish audio https://youtu.be/gCOyLW5Nsrk 

## Salaries and Wages Payable (Introductory)
{{< youtube MsczmIYJV24 >}}
>This video provides an introductory look at the accounting for accrued 

