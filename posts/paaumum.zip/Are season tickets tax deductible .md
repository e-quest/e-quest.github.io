---
title: "Are Season Tickets Tax Deductible? [Solved]"
ShowToc: true 
date: "2022-03-06"
author: "Eliza Harris" 
---

Sup, iam Eliza Harris, Hope you're doing good!
## Are Season Tickets Tax Deductible? [Solved]
Entertainment expenses, like a sporting event or tickets to a show, are still non-deductible.

## How to Get Business Deduction On Sports & Concert Tickets | Tax write-offs | CPA | Business Idea
{{< youtube 2UsEXMn59MU >}}
>With the change in the 

## GOP tax bill to get rid of season ticket tax deductions
{{< youtube 1V83XYSvpwk >}}
>GOP tax bill to get rid of 

## TAX EXPERT EXPLAINS Top 5 Tax Write-Offs for Small Businesses in Canada for 2022
{{< youtube rhGw361LXRw >}}
>00:00 Intro 01:30 

