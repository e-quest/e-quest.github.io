---
title: "Are Smokers More Likely To Develop Severe Disease With Covid-19? [Solved]"
ShowToc: true 
date: "2021-11-26"
author: "Leslie Barnett" 
---

Sup, iam Leslie Barnett, Have a happy day.
## Are Smokers More Likely To Develop Severe Disease With Covid-19? [Solved]
Tobacco smoking is a known risk factor for many respiratory infections and increases the severity of respiratory diseases. A review of studies by public health experts convened by WHO on 29 April 2020 found that smokers are more likely to develop severe disease with COVID-19, compared to non-smokers.

## Smokers are more likely to develop severe disease with COVID-19, compared to non-smokers.
{{< youtube s7RBMswPvLA >}}
>Stay away from rumours. The news that 

## Are Smokers More Likely to Develop a Severe Form of COVID-19? | What Dr. Amit Kr. Dey Says
{{< youtube hMJ7ulwZ-kk >}}
>Are Smokers More Likely to Develop

## Health experts: COVID-19 more dangerous for minorities and smokers
{{< youtube ErpbFOva_9c >}}
>COVID

