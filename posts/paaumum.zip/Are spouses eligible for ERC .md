---
title: "Are Spouses Eligible For Erc? [Solved]"
ShowToc: true 
date: "2021-11-26"
author: "Pamela Van" 
---

Hola, iam Pamela Van, Take it easy.
## Are Spouses Eligible For Erc? [Solved]
152(d)(2)(A) through (H), and the direct majority owner's wages are not eligible for the ERC. For the direct majority owner's spouse, if the direct majority owner has a family member under Sec.Sep 23, 2021

## Understand ERTC: How Owner’s & Spouses Qualify For Employee Retention Tax Credit [Over 50% Affect]
{{< youtube C0ZbLnsESMk >}}
>Owners & 

## This is Your Biggest ERC Mistake! | Learn How Related Parties Disqualifies Family Employee Wages
{{< youtube D_Oh1fcYVsk >}}
>The number 1 mistake being made right now with the Employee Retention Credit and 

## ERTC Owners: How to Qualify for IRS ERC (Employee Retention Tax Credit)
{{< youtube OndBOmcua9A >}}
>ERTC Update: Employee Retention Tax Credit aka IRS 

