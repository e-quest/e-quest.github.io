---
title: "Are Spouses Of Owners Eligible For Erc? [Solved]"
ShowToc: true 
date: "2022-02-02"
author: "Shannon Gustafson" 
---

Howdy, iam Shannon Gustafson, Hope you're doing good!
## Are Spouses Of Owners Eligible For Erc? [Solved]
Wages paid to individuals that are related to a more-than-50% owner do not count as wages for the ERC. However, wages paid to an owner and the owner's spouse count for the credit.

## Understand ERTC: How Owner’s & Spouses Qualify For Employee Retention Tax Credit [Over 50% Affect]
{{< youtube C0ZbLnsESMk >}}
>ERTC. ERTC Tax Credit. 

## This is Your Biggest ERC Mistake! | Learn How Related Parties Disqualifies Family Employee Wages
{{< youtube D_Oh1fcYVsk >}}
>The number 1 mistake being made right now with the Employee Retention Credit and 

## ERTC Owners: How to Qualify for IRS ERC (Employee Retention Tax Credit)
{{< youtube OndBOmcua9A >}}
>ERTC Update: Employee Retention Tax Credit aka IRS 

