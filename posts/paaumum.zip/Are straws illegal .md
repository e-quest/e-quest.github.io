---
title: "Are Straws Illegal? [Solved]"
ShowToc: true 
date: "2022-04-14"
author: "Veronica Brown" 
---

Howdy, iam Veronica Brown, Take it easy.
## Are Straws Illegal? [Solved]
If the state chooses not to regulate single-use plastics, the decisions fall to the cities and counties. This is where you find most of the plastic straw bans; cities like New York City, Charleston, South Carolina, and Miami Beach, Florida all have enacted their own bans on plastic straws and stirrers.

## Why plastic straw bans aren’t the answer.
{{< youtube _CAim_uGjcI >}}
>In this Our Changing Climate environmental video essay, I look at the controversy and debate behind plastic 

## Why Plastic Straws Suck
{{< youtube pdTBG929mgs >}}
>For years, the world has been relying on the ocean as a dumping ground for our plastic waste. This video of a sea turtle having a ...

## Did Ditching Plastic Straws Do More Harm Than Good? | One Small Step
{{< youtube 8gxq1XLqWIA >}}
>In 2018, as 

