---
title: "Are The Elderly More Vulnerable To The Coronavirus Disease? [Solved]"
ShowToc: true 
date: "2022-03-22"
author: "Dianna Rosenberger" 
---

Hi, iam Dianna Rosenberger, I hope your day goes well.
## Are The Elderly More Vulnerable To The Coronavirus Disease? [Solved]
The COVID-19 pandemic is impacting the global population in drastic ways. In many countries, older people are facing the most threats and challenges at this time. Although all age groups are at risk of contracting COVID-19, older people face significant risk of developing severe illness if they contract the disease due to physiological changes that come with ageing and potential underlying health conditions.Apr 3, 2020

## Coronavirus: Older people are significantly more vulnerable | 5 News
{{< youtube X9uK0Ysfe8A >}}
>▻ Certain groups can be 

## How will elderly and vulnerable people cope without COVID precautions?
{{< youtube UyK34gtCF10 >}}
>As we return to a society without 

## Coronavirus: How can the elderly and most vulnerable prepare? - BBC Newsnight
{{< youtube La5Kj1oiOdk >}}
>The 

