---
title: "Are There Alternatives To Fabric Masks During School Activities During The Covid-19 Pandemic? [Solved]"
ShowToc: true 
date: "2021-10-06"
author: "Gwendolyn Danielson" 
---

Hi, iam Gwendolyn Danielson, May your day be joyful.
## Are There Alternatives To Fabric Masks During School Activities During The Covid-19 Pandemic? [Solved]
In the context of COVID-19, some children may not be able to wear a mask due to disabilities or specific situations such as speech classes where the teacher needs to see their mouths. In these cases, face shields may be considered an alternative to masks, but they do not provide the equivalent protection in keeping the virus from being transmitted to others.Mar 7, 2022

## Are there alternatives to fabric masks during school activities during the COVID-19 pandemic?
{{< youtube neyFJvf0ZcY >}}
>00:00 - Are 

## Face Masks: Materials, Fit, and Filtration during the COVID-19 Pandemic | ARC IPC
{{< youtube K70-HBj9-zM >}}
>This webinar is sponsored by the Alabama Regional Center 

## Creating bespoke reusable face masks for the Covid-19 pandemic
{{< youtube 4IltjPBJWVU >}}
>A collaborative group of multidisciplinary academics and entrepreneurs led by Dr Adam A. Stokes have devised a system to ...

