---
title: "Are There Mini Strokes? [Solved]"
ShowToc: true 
date: "2022-03-27"
author: "Jean Hansberger" 
---

Sup, iam Jean Hansberger, Have a pleasant day.
## Are There Mini Strokes? [Solved]
A transient ischaemic attack (TIA) or "mini stroke" is caused by a temporary disruption in the blood supply to part of the brain. The disruption in blood supply results in a lack of oxygen to the brain.

## TIAs or mini strokes - what are the signs?
{{< youtube AolO-RWesUM >}}
>http://sunnyview.sunnybrook.ca // TIAs (transient ischemic attacks) are like 

## Explaining what a mini-stroke means
{{< youtube e760lnsvvdE >}}
>Senior Medical Correspondent Elizabeth Cohen explains what a "

## Mark's mini-stroke story
{{< youtube 9eGBVit7Ft4 >}}
>In 2011, Mark (28) had a TIA after he was hit by a car whilst walking home from work. Paramedics took Mark to hospital where he ...

