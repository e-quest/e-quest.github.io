---
title: "Are There Precautions To Take While Eating In A Restaurant During The Covid-19 Pandemic? [Solved]"
ShowToc: true 
date: "2021-10-10"
author: "Ellen Smith" 
---

Sup, iam Ellen Smith, Don’t overdo it!
## Are There Precautions To Take While Eating In A Restaurant During The Covid-19 Pandemic? [Solved]
See full answerThere is no evidence that the virus that causes COVID-19 is transmitted by food, including fresh fruits and vegetables. The virus can be killed while cooking food at temperatures of at least 70°C.Food buffets are not recommended because of the risk of close physical contact with others, shared serving implements and multiple people touching the surfaces on the buffet. Indoor dining spaces should have a maximum of 4 people in 10 square metres. The distance from the back of one chair to the back of another chair should be at least 1 metre apart for both indoor and outdoor dining, and guests that face each other should also be at this distance.Guests should be reminded when entering and leaving the area to clean their hands. When the physical distance of at least 1 metre cannot be guaranteed, masks are recommended to be worn by staff and guests.

## Planning to eat inside a restaurant? Here are some COVID safety precautions you can take
{{< youtube YB6IYfVT0Qk >}}
>Planning to 

## Is it safe to go to restaurants during coronavirus?
{{< youtube k8eLBK3a_NQ >}}
>There

## COVID-19 precautions for dining out
{{< youtube sZPXWcx9CVQ >}}
>COVID

