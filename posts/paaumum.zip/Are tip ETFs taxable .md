---
title: "Are Tip Etfs Taxable? [Solved]"
ShowToc: true 
date: "2022-09-15"
author: "Eugene Burke" 
---

Howdy, iam Eugene Burke, Have an awesome day!
## Are Tip Etfs Taxable? [Solved]
Because U.S. Treasurys are tax-free at the state and local level, interest payments from sovereign bond ETFs that hold U.S. Treasurys are also exempt from state and local income taxes. They are subject to federal taxes, however
.related ETFs.TickerNameYTD%TIPiShares TIPS Bond ETF-13.30%6 more rows

## Are ETFs tax-efficient?
{{< youtube IVgwr3F54RU >}}
>ETFs

## ETF and MUTUAL FUND TAXES - How are you taxed on ETFs?
{{< youtube 8laJYxXbOKY >}}
>How are 

## What are TIPS - Treasury Inflation Protected Securities
{{< youtube 6DXbZa-lfr8 >}}
>DISCLAIMER: I am not a financial advisor. These videos are for educational purposes only. Investing of any kind involves risk.

