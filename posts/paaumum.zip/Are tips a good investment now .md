---
title: "Are Tips A Good Investment Now? [Solved]"
ShowToc: true 
date: "2021-10-22"
author: "Rita Hickman" 
---

Sup, iam Rita Hickman, Don’t worry, it’s one day closer to the weekend.
## Are Tips A Good Investment Now? [Solved]
Consider TIPS if you're worried that inflation will remain high or if you're looking to help protect against an unexpected rise in inflation. With TIPS principal values indexed to the rate of inflation, they can help portfolios keep pace with inflation in a way that most other investments can't.

## Investing in Treasury Inflation-Protected Securities (TIPS)
{{< youtube 4XYEzLpgEpc >}}
>Fixed-income 

## I Bonds vs TIPS: What's Better As An Inflation Hedge | Inflation Protected Treasury Securities
{{< youtube bIq8XXo4Vfo >}}
>I Bonds vs 

## TIPS vs I Bonds--What's the Best Way to Hedge Against Inflation?
{{< youtube MlSkdslNZVc >}}
>TIPS

