---
title: "Are Tips A Liability? [Solved]"
ShowToc: true 
date: "2022-09-09"
author: "Theodore Ridenhour" 
---

Greetings, iam Theodore Ridenhour, Have a happy day.
## Are Tips A Liability? [Solved]
Tips are paid by your customers. That means you either track it as Liability (owed to staff) or as part of your income.

## HOW TO CONVERT A LIABILITY INTO AN ASSET - ROBERT KIYOSAKI, Rich Dad Poor Dad
{{< youtube A8vD_XO0vUU >}}
>Your house, 401K and IRA are NOT assets. In this video I will be teaching you the basic fundamentals of financial education.

## 30 CS:GO Tips Nobody Told You
{{< youtube ubiQEEgowYE >}}
>#csgo #voocsgo 0:00 Intro 1:01 The Video Patreon ▻ https://www.patreon.com/voocsgo 2nd Channel ...

## Effective meetings best practices: 8 tips for successful business meetings
{{< youtube Pes-dxtebSw >}}
>In this video we're going to talk about effective meetings best practices, so that every single meeting you hold is useful, productive, ...

