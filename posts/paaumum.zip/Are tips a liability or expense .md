---
title: "Are Tips A Liability Or Expense? [Solved]"
ShowToc: true 
date: "2022-03-15"
author: "Nicolas Burg" 
---

Namaste, iam Nicolas Burg, Peace out!
## Are Tips A Liability Or Expense? [Solved]
Tips are paid by your customers. That means you either track it as Liability (owed to staff) or as part of your income.

## HOW TO CONVERT A LIABILITY INTO AN ASSET - ROBERT KIYOSAKI, Rich Dad Poor Dad
{{< youtube A8vD_XO0vUU >}}
>Your house, 401K and IRA are NOT assets. In this video I will be teaching you the basic fundamentals of financial education.

## Cash Flow Tip 2 - Difference Between An Expense And Liability
{{< youtube 2JXANuYQhto >}}
>Clayton Daniel of Hillross Silverstone presents the second 

## Cara Menentukan Debit dan Kredit dengan Tepat
{{< youtube BIFV87JFkRI >}}
>Cara menentukan debit dan kredit sangat mudah jika anda paham aturan ini, silahkan anda simak video ini sampai selesai agar ...

