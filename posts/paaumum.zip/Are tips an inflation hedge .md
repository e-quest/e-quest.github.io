---
title: "Are Tips An Inflation Hedge? [Solved]"
ShowToc: true 
date: "2022-08-13"
author: "Nanci Tatum" 
---

Hola, iam Nanci Tatum, Have a pleasant day.
## Are Tips An Inflation Hedge? [Solved]
Unlike other bonds, which generate returns in nominal terms, TIPS are designed to be a direct hedge against inflation. Their principal value is designed to move up or down in line with the Consumer Price Index: If the CPI increases, their principal value increases.Aug 1, 2022

## Are TIPS Actually A Good Inflation Hedge?
{{< youtube EdVGJ4bphu0 >}}
>I want to give a huge thank you to George Kao whose generous support on Patreon is helping to keep this channel in the black!

## I Bonds vs TIPS: What's Better As An Inflation Hedge | Inflation Protected Treasury Securities
{{< youtube bIq8XXo4Vfo >}}
>I Bonds vs 

## TIPS vs I Bonds--What's the Best Way to Hedge Against Inflation?
{{< youtube MlSkdslNZVc >}}
>TIPS

